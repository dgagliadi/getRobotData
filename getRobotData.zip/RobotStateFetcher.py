import json
import sys
import threading
import time
import logging
import argparse


import bosdyn.client
from bosdyn.client import util
from bosdyn.client import spot_cam
from bosdyn.mission.client import MissionClient
from bosdyn.client.robot_state import RobotStateClient
from bosdyn.client.docking import DockingClient
from bosdyn.client.graph_nav import GraphNavClient
from bosdyn.client import ResponseError, RpcError, create_standard_sdk
from flask import jsonify

_LOGGER = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

detector_interface = "initialized"

class RobotStateHelpers:
    def __init__(self, robot, logger=_LOGGER):
        self.robot = robot
        self.robot.time_sync.wait_for_sync()
        self.robot_client = self.robot.ensure_client(RobotStateClient.default_service_name)
        self.mission_client = self.robot.ensure_client(MissionClient.default_service_name)
        self.graph_nav_client = self.robot.ensure_client(GraphNavClient.default_service_name)
        self.docking_client = self.robot.ensure_client(DockingClient.default_service_name)
    

    def get_robot_state(self): 
        f= open('output.txt', 'a')
        resp = ""
        # Fore reference to all robot states: https://protect-eu.mimecast.com/s/zEjnCp2mwcOK31qDUkIjVZ?domain=dev.bostondynamics.com
        robot_state = self.robot_client.get_robot_state()
        # For reference: https://protect-eu.mimecast.com/s/HOBSCqZnRskljKnWfMbMe3?domain=dev.bostondynamics.com
        comms_state = robot_state.comms_states
        print(comms_state)
        f.write(str(comms_state))
        
        # For reference: https://protect-eu.mimecast.com/s/Oc-PCr9oZfnolP79IxDroj?domain=dev.bostondynamics.com
        power_state = robot_state.power_state
        print(power_state)
        f.write(str(power_state))
        
        # For reference: https://protect-eu.mimecast.com/s/Oc-PCr9oZfnolP79IxDroj?domain=dev.bostondynamics.com
        battery_state = robot_state.battery_states
        print(battery_state)
        f.write(str(battery_state))
        resp = comms_state + power_state + battery_state
        f.close()

        # For reference: https://protect-eu.mimecast.com/s/G0PACvZvqsLKzpqXFWVUkl?domain=dev.bostondynamics.com
        #kinematic_state = robot_state.kinematic_state
        #print(kinematic_state)
        #f.write(str(kinematic_state))
        # For reference: https://protect-eu.mimecast.com/s/l_4QCwrw9hV93Jkph4l_pt?domain=dev.bostondynamics.com
        #foot_state = robot_state.foot_state
        #print(foot_state)
        #f.write(str(foot_state))
        # For reference: https://protect-eu.mimecast.com/s/easzCx1xqSRwonDOt4R4Aj?domain=dev.bostondynamics.com
        service_fault_state = robot_state.service_fault_state
        print(service_fault_state)
        f.write(str(service_fault_state))
        f.close()
        return("from get robot state")
    def get_docking_state(self):
        # For reference: https://protect-eu.mimecast.com/s/ICWECyXylh2k5qKnSK4Jgo?domain=dev.bostondynamics.com
        f= open('output.txt', 'a')
        # For refernece: https://protect-eu.mimecast.com/s/908sCzXzPhw9oQELfN7ca7?domain=dev.bostondynamics.com
        docking_state = self.docking_client.get_docking_state()
        print(docking_state)
        f.write(str(docking_state))
        f.close()
    def get_mission_state(self):
        # For reference to all MissionServices: https://protect-eu.mimecast.com/s/daxtCA1lqSl2ALBYtq-BWz?domain=dev.bostondynamics.com
        f= open('output.txt', 'a')
        # For reference: https://protect-eu.mimecast.com/s/Oc-PCr9oZfnolP79IxDroj?domain=dev.bostondynamics.com
        mission_state = self.mission_client.get_state()
        print(mission_state)
        f.write(str(mission_state))
        f.close()
    
    def get_localization_state(self):
        # For reference: https://protect-eu.mimecast.com/s/LSlECB6moIRB5p0otOsJDH?domain=dev.bostondynamics.com
        f= open('output.txt', 'a')
        localization_state = self.graph_nav_client.get_localization_state()
        print(localization_state)
        f.write(str(localization_state))
        f.close()
    
    def run(self):
        print("Running example... ")
        self.get_robot_state()
        self.get_mission_state()
        self.get_docking_state()
        self.get_localization_state()
    




def main(argv):
    
    import argparse
    print("1")
    parser = argparse.ArgumentParser()
    print("2")
    bosdyn.client.util.add_base_arguments(parser)
    print("3")
    bosdyn.client.util.add_service_hosting_arguments(parser)
    print("4")
    options, _ = parser.parse_known_args(argv)
    print("5")
    bosdyn.client.util.setup_logging(verbose=options.verbose)
    print("6")
    self_ip = bosdyn.client.common.get_self_ip(options.hostname)
    
    print("7")
    # Create robot object.
    sdk = create_standard_sdk('RobotStateClient', [MissionClient])
    print("8")
    robot = sdk.create_robot(options.hostname)
    print("9")
    spot_cam.register_all_service_clients(sdk)
    print("10")
    robot.authenticate("budadmin", "Bostondynamicsadmin")
    print("11")
    # Authenticate the robot object
    # if options.verbose:
    #     robot.authenticate("admin", "clientadmin123")
    # else:
    #     bosdyn.client.util.add_payload_credentials_arguments(parser)
    #     options = parser.parse_args(argv)
    #     robot.authenticate_from_payload_credentials(
    #         *bosdyn.client.util.get_guid_and_secret(options))
    print("12")
    robot.start_time_sync(time_sync_interval_sec=1)
    print("13")
    robot.time_sync.wait_for_sync()
    print("14")
    detector_interface = RobotStateHelpers(robot, logger=_LOGGER)
    resp = detector_interface.get_robot_state()
    print("before response")
    print(resp)
    print("after reponse")
    return(resp)
    
    try:
        # Thread to constantly scan the ring camera
        detector_thread = threading.Thread(target=detector_interface.run, args=())
        detector_thread.start()
    except (ResponseError, RpcError) as err:
        _LOGGER.error("[Main] Failed to initialize robot communication: %s" % err)
        return False
    
if __name__ == '__main__':
    if not main(sys.argv[1:]):
        sys.exit(1)

